<?php

require_once('dbconfig.php');
$POST = file_get_contents('php://input');
session_start();
$email=$_SESSION['email'];
$description=$_POST['source0'];
$seeking=$_POST['source1'];
$query1="update music set description='$description',seeking='$seeking' where email='$email'";
$query = mysqli_query($connection,$query1);

echo "success";
mysqli_close($connection); // Connection Closed
?>