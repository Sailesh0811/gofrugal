$(document).ready(function(){
	// body...

	
 
})