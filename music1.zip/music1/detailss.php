<?php
require('dbconfig.php');
$POST = file_get_contents('php://input');
session_start();

$_SESSION['givenname']=$_POST['id'];
$query = 'select * form posts where username="$_POST["id"]"';
$result=mysqli_query($connection,$query);
if( mysqli_num_rows($result)>0) {
    $row = mysqli_fetch_assoc($result);
    $useremail = $row['useremail'];
    if ($useremail == $_SESSION['email']) {
        echo "error";
    } else {
        echo "success";
    }
}
?>