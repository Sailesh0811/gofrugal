<?php
require_once('dbconfig.php');
$POST = file_get_contents('php://input');
session_start();
$useremail=$_SESSION['email'];
$id = $_POST['post_id'];
$username = $_SESSION['email'];
date_default_timezone_set("Asia/Kolkata");
 $date=Date("d-m-y h:m:s");
$query = "insert into likes(post_id,time_stamp,username) values ('$id','$date','$username')";
$
//echo mysqli_num_rows($result);
if(mysqli_query($connection,$query))
{
	echo "success";
}
else
{
	echo "error";
}
?>