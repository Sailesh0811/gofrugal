var routerApp = angular.module('routerApp', ['ui.router']);

routerApp.config(function($stateProvider, $urlRouterProvider) {

    $urlRouterProvider.otherwise('main/home/post');

    $stateProvider

    // HOME STATES AND NESTED VIEWS ========================================
        .state('main', {
            url: '/main',
            templateUrl: 'index.html'
        })
        .state('feeds', {
            url: '/feeds',
            templateUrl: 'feeds.html'
        })
        .state('messages', {
            url: '/messages',
            template: '<h1>Will be done soon</h1>'
        }).state('sound', {
            url: '/sound',
            template: '<h1>Will be done soon</h1>'
        })
        .state('map', {
            url: '/map',
            templateUrl: 'location/loc.html'
        })
        .state('main.home', {
            url: '/home',
            templateUrl: 'post.html'
        })
        .state('main.home.post', {
            url: '/post',
            templateUrl: 'posts.php'

        })

        // nested list with just some random string data

        .state('main.home.followers', {
            url: '/followers',
            templateUrl: 'followers.php'
        })
        .state('main.home.following', {
            url: '/following',
            templateUrl: 'following.php'
        })
        // ABOUT PAGE AND MULTIPLE NAMED VIEWS =================================
        .state('main.privacy', {
            url:'/privacy',
            templateUrl: 'privacy settings.html'
        })
        .state('main.map', {
            url:'/map',
            template: '<h1>Will be done soon</h1>'
        })
        .state('main.activity', {
            url:'/activity',
            template: '<h1>Will be done soon</h1>'
        })
        .state('main.bug', {
            url:'/bug',
            template: '<h1>Will be done soon</h1>'
        });

});









































