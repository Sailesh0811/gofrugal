


                  




var details;

$(document).ready(function(){
  $('#postss').empty();
		
var details="";var i=1;


$.ajax({
        type: 'post',
        url: 'profile.php',
        // dataType:"html",
    
        
       success:function( data ) {
       	if(data=="error"){
       		window.location="./signup.html";

       	}else{
                details = JSON.parse(data);
                console.log(details);
    var firstname=details[0][0];                
	var lastname=details[0][1];
	var stagename=details[0][2];
	var email=details[0][3];
	var gender=details[0][4];
	var options=details[0][5];
	var instruments=details[0][6];
	var level=details[0][7];
	var locality=details[0][10];
	var city=details[0][11];
	var description=details[0][12];
	var seeking=details[0][13];
var res = instruments.split(",");
		instruments="";
	for (var i = 0 ; i<res.length ; ) {
		instruments+=res[i]+"<br>";
		//console.log(i);
		i++;	
	}
	//console.log(instruments);
	document.getElementById('firstname').innerHTML=firstname;
	document.getElementById('first').innerHTML=firstname;
		document.getElementById('city').innerHTML=locality+","+city;
		document.getElementById('place').innerHTML=locality+","+city;
		document.getElementById('seeking').innerHTML=seeking;
		document.getElementById('description').innerHTML=description;
		document.getElementById('instr').innerHTML=instruments;



        }
   
      }
   });
$('#profile').click(function(){
var details="";var i=1;


$.ajax({
        type: 'post',
        url: 'profile.php',
        // dataType:"html",
    
        
       success:function( data ) {
                details = JSON.parse(data);
                console.log(details);
    var firstname=details[0][0];                
	var lastname=details[0][1];
	var stagename=details[0][2];
	var email=details[0][3];
	var gender=details[0][4];
	var options=details[0][5];
	var instruments=details[0][6];
	var level=details[0][7];
	var locality=details[0][10];
	var city=details[0][11];
	var description=details[0][12];
	var seeking=details[0][13];
var res = instruments.split(",");
		instruments="";
	for (var i = 0 ; i<res.length ; ) {
		instruments+=res[i]+"<br>";
		//console.log(i);
		i++;	
	}
	//console.log(instruments);
	document.getElementById('firstname').innerHTML=firstname;
	document.getElementById('first').innerHTML=firstname;
		document.getElementById('city').innerHTML=locality+","+city;
		document.getElementById('place').innerHTML=locality+","+city;
		document.getElementById('seeking').innerHTML=seeking;
		document.getElementById('description').innerHTML=description;
		document.getElementById('instr').innerHTML=instruments;



        }
   
      
   });





});
 $('.modal-trigger').leanModal({
      dismissible: true, // Modal can be dismissed by clicking outside of the modal
      opacity: .5, // Opacity of modal background
      in_duration: 300, // Transition in duration
      out_duration: 200, // Transition out duration
      starting_top: '4%', // Starting top style attribute
      ending_top: '7%%', // Ending top style attribute
      ready: function() { alert('Ready'); }, // Callback for Modal open
      complete: function() { alert('Closed'); } // Callback for Modal close
    }
  );

$('#Upload').click(function(){
	$('#modal1').openModal();
});


$('#close-modal').click(function(){
	$('#modal1').closeModal();
});

var tags=[];var i=0;
$('#add').click(function(){
	if(tags.length<4){
        $('input.autocomplete').autocomplete({
            data: {
                "Apple": null,
                "Microsoft": null,
                "Google": 'http://placehold.it/250x250'
            }
        });
	var tag=$('#autocomplete').val();
       tags[i]=tag;

       Materialize.toast(tag,6000);
       $('#autocomplete').val('#');
   }
   else{
   	Materialize.toast('Maximum limit exceeded');
   }

});
        $('#add1').click(function(){
            if(tags.length<4){
                $('input.autocomplete1').autocomplete({
                    data: {
                        "Apple": null,
                        "Microsoft": null,
                        "Google": 'http://placehold.it/250x250'
                    }
                });
                var tag=$('#autocomplete1').val();
                tags[i]=tag;

                Materialize.toast(tag,6000);
                $('#autocomplete1').val('#');
            }
            else{
                Materialize.toast('Maximum limit exceeded');
            }

        });
console.log(i);


console.log(tags);
$('#upload1').on('click', function() {
	for(var j=tags.length;j<4;j++)
{
tags[j] = ''; 	
}
	var music_name=$('#music_name1').val();
	console.log(music_name);
    var file_data = $('#file').prop('files')[0];   
    var form_data = new FormData();                  
    form_data.append('file', file_data);
    var file_data2 = $('#cover1').prop('files')[0];

    form_data.append('file', file_data);
     $.ajax({
                url: 'postdb.php', // point to server-side PHP script 
                  // what to expect back from the PHP script, if anything
                async: false,
                data: {
                 music_name:music_name,
                 tags:tags
                },                     
                type: 'post',
                success: function(php_script_response){
                  alert(php_script_response); // display response from the PHP script, if any
                }
     });
                                
    $.ajax({
                url: 'upload.php', // point to server-side PHP script 
                dataType: 'text',  // what to expect back from the PHP script, if anything
                cache: false,
                contentType: false,
                processData: false,
                data: form_data,                        
                type: 'post',
                success: function(php_script_response){

                    alert(php_script_response); // display response from the PHP script, if any
                    window.location = "./main.html";
                }
     });
});
        $('#upload2').on('click', function() {
            for(var j=tags.length;j<4;j++)
            {
                tags[j] = '';
            }
            var music_name=$('#music_name1').val();
            var videourl=$('#videourl').val();
            console.log(music_name);
            var file_data1 = $('#cover2').prop('files')[0];

            form_data.append('file', file_data);
            $.ajax({
                url: 'postdbes.php', // point to server-side PHP script 
                // what to expect back from the PHP script, if anything
                async: false,
                data: {
                    music_name:music_name,
                    tags:tags,
                    videourl:videourl
                },
                type: 'post',
                success: function(php_script_response){
                    alert(php_script_response); // display response from the PHP script, if any
                }
            });

            $.ajax({
                url: 'upload1.php', // point to server-side PHP script 
                dataType: 'text',  // what to expect back from the PHP script, if anything
                cache: false,
                contentType: false,
                processData: false,
                data: form_data,
                type: 'post',
                success: function(php_script_response){

                    alert(php_script_response); // display response from the PHP script, if any
                    window.location = "./main.html";
                }
            });
        });


}
);


