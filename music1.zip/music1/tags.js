$ ( function() {
    var string="";var skills="";
    console.log(string,skills);
    var availableTags = [
     "Vocal",
      "Acoustic Guitar",
      "Lead Guitar",
      "Rythm Guitar",
      "Drums/percussion",
      "Keyboards/piano",
      "Violin/Fiddle",
      "Flute",
      "Songwriter",
      "Bass guitar",
      "DJ/ Mixer",
      "Harmonica",
      "Saxophone",
      "Trumpet",
      "Ukulele",
      "Dholak",
      "Dumroo",
      "Ghatam",
      "Tabla",
      "Mridangam",
      "Sitar",
      "Tanpura",
      "Veena",
      "Sarangi"
    ];
    $( "input.autocomplete" ).autocomplete({
      source: availableTags
    });

});