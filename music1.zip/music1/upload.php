<?php
require_once('dbconfig.php');

session_start();
$useremail=$_SESSION['email'];
$query1 = 'select * from posts order by post_id desc ';

$result1 = mysqli_query($connection,$query1);
$row=mysqli_fetch_assoc($result1);

echo $ids = $row['post_id'];


    if ( 0 < $_FILES['file']['error'] ) {
        echo 'Error: ' . $_FILES['file']['error'] . '<br>';
    }
    else {
    	$url='uploads/' . $_FILES['file']['name'];
        move_uploaded_file($_FILES['file']['tmp_name'],$url );
        $query="update posts set picture = '$url' where post_id = '$ids'" ;
       
		if($result = mysqli_query($connection,$query)){
			echo json_encode("Success");
		}
		else{
			echo "error";
		}
        
    }

?>