<?php
require_once('dbconfig.php');

session_start();
$useremail=$_SESSION['email'];
$username=$_SESSION['username'];
$music_name=$_POST['music_name'];
$tags=$_POST['tags'];
$videourl = $_POST['videourl'];


date_default_timezone_set("Asia/Kolkata");
echo $date=Date("d-m-y h:m:s");
$query="Insert into posturl(useremail,username,music_name,tag1,tag2,tag3,tag4,time_stamp,videourl) values('$useremail','$username','$music_name','$tags[0]','$tags[1]','$tags[2]','$tags[3]','$date',$videourl)";
$query2 = 'update music set likes = likes + 1 where email="$useremail"';
if($result = mysqli_query($connection,$query)){
if($result = mysqli_query($connection,$query2)) {
    echo "Success";
}
}
else{

    echo "error";
}
?>		  