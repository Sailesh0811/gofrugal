<?php
require_once('dbconfig.php');
$POST = file_get_contents('php://input');
session_start();
$email=$_SESSION['email'];
$userdetail= array();
$query="select * from music where email='$email'";
$result=mysqli_query($connection,$query);
if(mysqli_num_rows($result)>0){
	$row=mysqli_fetch_assoc($result);
	$i=0;$j=0;
	$userdetail[$i][$j++]=$row['firstname'];
	$userdetail[$i][$j++]=$row['lastname'];
	$userdetail[$i][$j++]=$row['stagename'];
	$userdetail[$i][$j++]=$row['email'];
	$userdetail[$i][$j++]=$row['gender'];
	$userdetail[$i][$j++]=$row['options'];
	$userdetail[$i][$j++]=$row['instruments'];
	$userdetail[$i][$j++]=$row['level'];
	$userdetail[$i][$j++]=$row['lat'];
	$userdetail[$i][$j++]=$row['lng'];
	$userdetail[$i][$j++]=$row['locality'];
	$userdetail[$i][$j++]=$row['city'];
	$userdetail[$i][$j++]=$row['description'];
	$userdetail[$i][$j++]=$row['seeking'];
	$userdetail[$i][$j++]=$row['likes'];
	$userdetail[$i][$j++]=$row['followers'];
	$userdetail[$i][$j++]=$row['followings'];

	echo json_encode($userdetail);
	}
	else
	{
		echo "error";
	}
	
?>