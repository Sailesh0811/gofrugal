$(document).ready(function(){
	$('#postss').empty();
});

