-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 17, 2016 at 02:20 PM
-- Server version: 5.6.17-log
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `some`
--

-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

CREATE TABLE IF NOT EXISTS `chat` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `sent_on` varchar(25) NOT NULL,
  `message_to` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=61 ;

--
-- Dumping data for table `chat`
--

INSERT INTO `chat` (`id`, `user_id`, `message`, `sent_on`, `message_to`) VALUES
(58, 'harshithmullapudi@gmail.com', 'hello', '17-09-16 11:09:57', 'ngsaileshsaran@gmail.com'),
(59, 'harshithmullapudi@gmail.com', 'how are you?!', '17-09-16 11:09:27', 'ngsaileshsaran@gmail.com'),
(60, 'ngsaileshsaran@gmail.com', 'idiot', '17-09-16 11:09:08', 'ngsaileshsaran@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--

CREATE TABLE IF NOT EXISTS `likes` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `post_id` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `time_stamp` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `likes`
--

INSERT INTO `likes` (`id`, `post_id`, `username`, `time_stamp`) VALUES
(12, 18, 'ngsaileshsaran@gmail.com', '16-10-16 12:10:16'),
(13, 2, 'ngsaileshsaran@gmail.com', '16-10-16 12:10:12'),
(14, 1, 'ngsaileshsaran@gmail.com', '16-10-16 12:10:54');

-- --------------------------------------------------------

--
-- Table structure for table `music`
--

CREATE TABLE IF NOT EXISTS `music` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `stagename` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `options` varchar(20) NOT NULL,
  `instruments` varchar(255) NOT NULL,
  `level` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `seeking` varchar(255) NOT NULL,
  `lat` varchar(255) NOT NULL,
  `lng` varchar(255) NOT NULL,
  `locality` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=99 ;

--
-- Dumping data for table `music`
--

INSERT INTO `music` (`id`, `firstname`, `lastname`, `stagename`, `email`, `password`, `gender`, `options`, `instruments`, `level`, `description`, `seeking`, `lat`, `lng`, `locality`, `city`) VALUES
(96, 'Shailesh', 'Dheep', 'hbhbhb', 'ngsaileshsaran@gmail.com', 'sai12345', 'male', 'musician', 'Acoustic Guitar,', 'Beginner,', 'Hello', 'How are you?', '10.7283732', '79.0217688', 'Tirumalaisamudram', 'Thanjavur'),
(97, 'harshith', 'mullapudi', 'sailesh', 'harshithmullapudi@gmail.com', 'santhu', 'male', 'musician', 'Acoustic Guitar,Keyboards/piano,', 'Beginner,Beginner,', 'i am bad boy', 'sailesh', '', '', '', ''),
(98, 'Vignesh', 'V', 'Sastra', 'venkatesan.vignesh@gmail.com', 'vignesh96', 'male', 'musician', 'Vocal,Tabla,', 'Beginner,Intermediate,', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE IF NOT EXISTS `posts` (
  `post_id` int(9) NOT NULL AUTO_INCREMENT,
  `useremail` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `music_name` varchar(255) NOT NULL,
  `tag1` varchar(255) NOT NULL,
  `tag2` varchar(255) NOT NULL,
  `tag3` varchar(255) NOT NULL,
  `tag4` varchar(255) NOT NULL,
  `playtime` varchar(255) NOT NULL,
  `likes` int(9) NOT NULL,
  `comments` varchar(9) NOT NULL,
  `picture` varchar(255) NOT NULL,
  `time_stamp` varchar(255) NOT NULL,
  PRIMARY KEY (`post_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`post_id`, `useremail`, `username`, `music_name`, `tag1`, `tag2`, `tag3`, `tag4`, `playtime`, `likes`, `comments`, `picture`, `time_stamp`) VALUES
(1, 'ngsaileshsaran@gmail.com', 'sailesh', 'fhjgkjhgjhg', 'fdhgfdhgfdhgd', '#jhgkjhgkjhg', '#jhjgkjhgkjhg', '#gkjhgkjhgj', '', 0, '', 'uploads/1.mp3', '23-09-16 11:09:00'),
(2, 'ngsaileshsaran@gmail.com', 'sailesh', 'vhvvjhv', '#nnll', '', '', '', '', 0, '', 'uploads/2.mp3', '25-09-16 10:09:03'),
(18, 'ngsaileshsaran@gmail.com', 'sailesh', '24', '#love', '', '', '', '', 0, '', 'uploads/Naan_Un-StarMusiQ.Com.mp3', '11-10-16 11:10:43');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `username` varchar(255) NOT NULL,
  `email` varchar(2555) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`username`, `email`, `id`) VALUES
('John', 'john@demo.fr', 1),
('sabrina', 'Sabrina@demo.Fr', 2),
('sailesh', 'ngsaileshsaran@gmail.com', 3),
('harshith', 'harshithmullapudi@gmail.com', 4);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
