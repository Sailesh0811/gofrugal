<?php
$POST = file_get_contents('php://input');
/**
 * Created by PhpStorm.
 * User: harsh
 * Date: 01-09-2016
 * Time: 21:53
 */
for($i=0;$i<100;$i++) {
    echo '<div class="chip">
    <img src="deepika.jpg" alt="Contact Person">
Deepika  </div>';
}
?>