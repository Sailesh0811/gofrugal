<?php
require_once('dbconfig.php');
session_start();
$useremail=$_SESSION['email'];
$id = $_POST['post_id'];
$username = $_SESSION['username'];
$query = "select * from likes where username = '$username' and post_id = '$id'";
$result=mysqli_query($connection,$query);//echo mysqli_num_rows($result);
if( mysqli_num_rows($result)>0)
{
	echo "success";
}
else
{
	echo "error";
}
?>