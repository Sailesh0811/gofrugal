<?php
require_once('dbconfig.php');
$POST = file_get_contents('php://input');
session_start();
$email=$_SESSION['email'];
$instruments=$_POST['source0'];
$level=$_POST['source1'];
$query1="update music set instruments='$instruments',level='$level' where email='$email'";
//$query1="INSERT INTO music(firstname,lastname,,stagename,email) VALUES ('$firstname',)"
$query = mysqli_query($connection,$query1);

echo json_encode("Form Submitted Succesfully");
mysqli_close($connection); // Connection Closed

?>