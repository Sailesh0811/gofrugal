
$(document).ready(function(){
	$('#get').click(function(){
		var email=$('#get').val();
		$.ajax({
			method:"post",
			url:"./getmessages.php",
			data:{email:email},
			success:function(data){
				var some=JSON.parse(data);
				console.log(some);var str="";
				for(var i=0;i<some.length;i++){
					str+=some[i]['user_id']+";"+some[i]['message']+"<br>";
				document.getElementById('chat').innerHTML=str;
			}
			}
	});

});	
	
	$('#ng').click(function(){
		$('#chat').prepend('<input type="text" name="idiot" id="idiot" value="hello"><button type="button" id="send" value="aad">SEND</button>');
		 
		$('#send').click(function(){
			var message=$('#idiot').val();
		 console.log($('#idiot').val());
		 var email=$('#ng').val();
			$.ajax({
			method:"post",
			url:"./addmessages.php",

			data:{message:message,email:email},
			success:function(data){
				console.log(data);
			}
			
	});


		});

	

});
	

});