<?php
require_once('../dbconfig.php');
session_start();
echo $usermail=$_SESSION['email'];
echo $message=$_POST['message'];
echo $to=$_POST['email'];
date_default_timezone_set("Asia/Kolkata");
echo $date=Date("d-m-y h:m:s");
$query="insert into chat (user_id,message,sent_on,message_to) values('$usermail','$message','$date','$to')";
if($result=mysqli_query($connection,$query)){

}
else{
	echo $connection->error;
}
echo "Success";
mysqli_close($connection);
?>