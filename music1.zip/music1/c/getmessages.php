<?php
require_once('../dbconfig.php');
session_start();
$from=$_SESSION['email'];
$to=$_POST['email'];//$_POST['to'];
$query="SELECT s.*
FROM
    (
        select * from chat where user_id='$from' and message_to='$to'
          union all
        select * from chat where user_id='$to' and message_to='$from'
    ) s
ORDER BY s.sent_on";
if($result1  = mysqli_query($connection,$query)){

}
else{
	echo $connection->error;
}
$message=array();
while ($row=mysqli_fetch_assoc($result1)) {
	$message[]=$row;
}
echo json_encode($message);
?>