$(document).ready(function(){
  $('#postss').empty();

var username='';  
//
$.ajax({
        type: 'post',
        url: 'postss.php',
        // dataType:"html",
    
        
       success:function(data) {

        if(data=="error"){
          window.location="./signup.html";

        }else{

                details = JSON.parse(data);
                console.log(details);$('#postss').empty();

                for(var i=0;i<details.length;i++) {
                    username = details[i][0];
                    var music_name = details[i][1];
                    var tag1 = details[i][2];
                    var tag2 = details[i][3];
                    console.log(tag2);
                    var tag3 = details[i][4];
                    var tag4 = details[i][5];
                    var picture = details[i][6];
                    var id = details[i][7];
                    var likeno = details[i][8];
                    var music = details[i][9];
                    var videourl = details[i][10];
                    var music_cover = details[i][11];

if(music ==  0){
    console.log(picture.duration);
                    var str = ' <div class="post" id="' + id + '"> <div class="col s12 m7 "  ><div class="card horizontal"><div style="width:35%;" class="card-image"><img style="width:100%;" src="';
                    str = str + music_cover;
                    str = str + '"></div><div class="card-stacked" ><div class="card-content"><h5 id="songname" ><strong>';
                    str = str + music_name;
                    str = str + '</strong></h5><p id="name"><i><a class="btn nammee" value="';
                    str = str + username;
                    str = str + '">';
                    str = str + username;
                    str = str + "</a>";
                    if (tag1 == "") {
                        str = str;
                    }
                    else {
                        str = str + '</i></p><br> <p><div class="chip" id="tag1">';
                        str = str + tag1;
                    }
                    if (tag2 == "") {
                        str = str;
                    }
                    else {
                        str = str + '</div><div class="chip" id="tag2">';
                        str = str + tag2;
                    }
                    if (tag3 == "") {
                        str = str;
                    }
                    else {
                        str = str + '</div><div class="chip" id="tag3">';
                        str = str + tag3;
                    }
                    if (tag4 == "") {
                        str = str;
                    }
                    else {
                        str = str + '</div><div class="chip" id="tag4">';
                        str = str + tag4;
                    }


                    str = str + ' </div></p></div><div class="card-action"><p><b>Time:4.13</b><a style="margin-left:70px;" class="waves-effect waves-light btn play" value=" ';
                    str = str + picture;
                    str = str + '" id=';

                    str = str + id;
                    str = str + '>play</a>';
                    str = str + '<a style="margin-left:70px;" class="waves-effect waves-light btn liked" value="" id="';
                    str = str + id + '2';
                    str = str + '">liked</a><a style="margin-left:70px;" class="waves-effect waves-light btn like" value="" id=';
                    str = str + id + '1';
                    str = str + '>like</a></p></div></div></div></div></div>';
                    $('#postss').append(str);
                    $('.liked').hide();
                    $('.like').hide();
                }
                    else
{
    var str = ' <div class="post" id="' + id + '"> <div class="col s12 m7 "  ><div class="card horizontal"><div style="width:35%;" class="card-image"><img style="width:100%;" src="';
    str = str + music_cover;
    str = str + '"></div><div class="card-stacked" ><div class="card-content"><h5 id="songname" ><strong>';
    str = str + music_name;
    str = str + '</strong></h5><p id="name"><i><a class="btn nammee" value="';
    str = str + username;
    str = str + '">';
    str = str + username;
    str = str + "</a>";
    if (tag1 == "") {
        str = str;
    }
    else {
        str = str + '</i></p><br> <p><div class="chip" id="tag1">';
        str = str + tag1;
    }
    if (tag2 == "") {
        str = str;
    }
    else {
        str = str + '</div><div class="chip" id="tag2">';
        str = str + tag2;
    }
    if (tag3 == "") {
        str = str;
    }
    else {
        str = str + '</div><div class="chip" id="tag3">';
        str = str + tag3;
    }
    if (tag4 == "") {
        str = str;
    }
    else {
        str = str + '</div><div class="chip" id="tag4">';
        str = str + tag4;
    }


    str = str + ' </div></p></div><div class="card-action"><p><b>Time:4.13</b><a style="margin-left:70px;" class="waves-effect waves-light btn plays" value=" ';
    str = str + picture;
    str = str + '" id=';

    str = str + id + '9';
    str = str + '>play</a>';
    str = str + '<a style="margin-left:70px;" class="waves-effect waves-light btn liked" value="" id="';
    str = str + id + '2';
    str = str + '">liked</a><a style="margin-left:70px;" class="waves-effect waves-light btn like" value="" id=';
    str = str + id + '1';
    str = str + '>like</a></p></div></div></div></div></div>';
    $('#postss').append(str);
    $('.liked').hide();
    $('.like').hide();
}
                    }
                    $('.nammee').on("click", function () {
                        window.event.stopPropagation();
                        id = this.id;
                        var ids = ($(this).attr('value'));
                        var lenn = ids.length;
                        ids = ids.slice(3, lenn);
                        console.log(ids);
                        $.ajax({
                            type: 'post',
                            url: 'detailss.php',
                            data: {id: ids},
                            success: function (data) {
                                console.log(data);
                                if (data == 'success') {
                                    var url = "neww.html";
                                    var win = window.open(url, '_blank');
                                    //win.focus();
                                }
                                else {
                                    window.location = './main.html';
                                }
                            }
                        });
                    });
                    $('.like').on("click", function () {
                        window.event.stopPropagation();

                        var ids = this.id;
                        var lenn = ids.length;
                        ids = ids.slice(0, lenn - 1);
                        console.log(lenn);
                        $.ajax({
                            type: 'post',
                            url: 'likes.php',
                            data: {

                                post_id: ids
                            },
                            // dataType:"html",


                            success: function (data) {
                                console.log(data)
                                if (data == 'success') {

                                    console.log(ids);
                                    console.log("ids of this");
                                    $('#' + ids + '1').hide();
                                    $('#' + ids + '2').show();


                                    // window.location = ./main.html;
                                }

                                else {


                                    alert(data);


                                }
                            }

                        });


                    });
                    $('.play').on("click", function () {
                        window.event.stopPropagation();

                        var ids = ($(this).attr('value'));


                        //var values=document.getElementById(ids).value;
                        //alert(ids);console.log();
                        $('#wrapper').empty();
                        var str = '<audio autoplay="autoplay" controls><source src="';
                        str = str + ids + '"></audio>';
                        $('#wrapper').append(str);
                    });
            $('.plays').on("click", function () {
                window.event.stopPropagation();

                var ids = ($(this).attr('value'));
                ids = ids.slice(0, lenn - 1);

                //var values=document.getElementById(ids).value;
                //alert(ids);console.log();
               var stt = '<div class="video-container"><iframe width="853" height="480" src="';
                stt = stt + ids;
                stt = stt + '" frameborder="0" allowfullscreen></iframe></div>';
                $('#video').append(stt);
                $('#modal13').modal('open');
            });
                }
        }
        

  });
  


var str1= '';
var id;


                  
                  $.ajax({
        type: 'post',
      
        url: 'postss.php',
        // dataType:"html",
    
        
       success:function(data) {

        if(data=="error"){
          window.location="./signup.html";

        }else{
                details = JSON.parse(data);
                console.log(details);

                for(var i=0;i<details.length;i++){
       var username=details[i][0];                
     var music_name=details[i][1];
     var tag1=details[i][2];
       var tag2=details[i][3];
       console.log(tag2);
       var tag3=details[i][4];
       var tag4=details[i][5];
       var picture=details[i][6];  
        id=details[i][7];
console.log(id);
        
somes(id);




       
    }
  }
  
}
});
function somes(post_id)
  {
    console.log(post_id);
$.ajax({
        type: 'post',
     
        url: 'like.php',
        data : 
        {
         
          post_id : post_id
        },
        // dataType:"html",
    
        
       success:function(data) {
        console.log(data);
        console.log("ahsdgkjhagsdf");
                if(data == 'success')

        {
          console.log("liked");
          $('#'+post_id+'1').hide();

  $('#'+post_id+'2').show();

 
}
  
  else
  {
    console.log("not liked");
$('#'+post_id+'2').hide();
 
$('#'+post_id+'1').show();

   
  }
        }
        
    });


  }                
                });




                  