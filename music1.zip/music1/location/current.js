 
 $(document).ready(function(){
  $("#loc").click(function(){
 var successCallback = function(position){
 var x = position.coords.latitude;
 var y = position.coords.longitude;
 displayLocation(x,y);
 storecoordinates(x,y);
 //console.log(city);
  };

 navigator.geolocation.getCurrentPosition(successCallback);
 function displayLocation(latitude,longitude){
        var request = new XMLHttpRequest();
       var method = 'GET';
       var url = 'http://maps.googleapis.com/maps/api/geocode/json?latlng='+latitude+','+longitude+'&sensor=true';
       var async = true;
       request.open(method, url, async);
       request.onreadystatechange = function(){
       if(request.readyState == 4 && request.status == 200){
         var data = JSON.parse(request.responseText);
         //alert(request.responseText); // check under which type your city is stored, later comment this line
         var addressComponents = data.results[0].address_components;
         for(i=0;i<addressComponents.length;i++){
            var types = addressComponents[i].types
            //alert(types);
            if(types=="administrative_area_level_2,political"){
                          var  city=addressComponents[i].long_name; 
                          storecity(city);

                       
            }
            if(types=="locality,political"){
              var locality=addressComponents[i].long_name;// this should be your city, depending on where you are          
              storelocality(locality);
             }
             
             
           }
        //alert(address.city.short_name);
         
        
       }
    };
   request.send();
   };
   function storecity(city){
      var xmlhttp = new XMLHttpRequest();
var url = "location/city.php?city="+city;
//console.log(username);
xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
        myFunction(xmlhttp.responseText);
    }
}
xmlhttp.open("GET", url, true);
xmlhttp.send();
      console.log(city);
   }
     function myFunction(response){
     locations = JSON.parse(response);
   }
   function storelocality(locality){
    var xmlhttp = new XMLHttpRequest();
var url = "location/locality.php?locality="+locality;
//console.log(username);
xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
        myFunction(xmlhttp.responseText);
    }
}
xmlhttp.open("GET", url, true);
xmlhttp.send();
      console.log(locality);
   }
   function storecoordinates(lat,lng){
    var xmlhttp = new XMLHttpRequest();
var url = "location/lat.php?lat="+lat+"&lng="+lng;
//console.log(username);
xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
        myFunction(xmlhttp.responseText);
    }
}
xmlhttp.open("GET", url, true);
xmlhttp.send();
      console.log(lat+""+lng);
   }
  //console.log(city);

  
 
});
});
 