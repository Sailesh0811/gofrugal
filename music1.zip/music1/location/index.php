<?php
  require_once('./dbconfig.php');
  $username="";
  session_start();
  if(isset($_POST['submit'])){
  	$username=$_POST['name'];
  	$_SESSION['username']=$username;
  	$sql="insert into location (username) values('$username')";
  	if($con->query($sql)){
  		echo "<script>alert('Your ussername is saved');</script>";
  	}
  }


?>
<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no">
    <meta charset="utf-8">
    <title>Tunezhub</title>
    
    <style>      
    </style>
  </head>
  <body>
  <script type="text/javascript">
  	var successCallback = function(position){
 var x = position.coords.latitude;
 var y = position.coords.longitude;
};
navigator.geolocation.getCurrentPosition(successCallback);
  </script>
<form method="post">
	Enter your username:<input type="text" name="name">
	<input type="submit" value="submit" name="submit">
	To know your location <a href="./geo.html">click here</a>
</form>

</body>
</html>
