<?php header('Access-Control-Allow-Origin: *'); 
	require_once('dbconfig.php');
	
	$location= array();
	$sql="select * from music";
	$result=$con->query($sql);
	  $rows = $result->num_rows;	
	$i=0;
		while($row = $result->fetch_assoc()){
					
			$location[$i][0]=$row['email'];
			$location[$i][1]=$row['lat'];
			$location[$i][2]=$row['lng'];
			$location[$i][3]=$row['locality'];
			$location[$i][4]=$row['city'];
			$i++;
		}

		
	

	echo $json=json_encode($location);

	
	

?>