<?php 
	require_once('dbconfig.php');session_start();
	$locality=$_GET['locality'];$username=$_SESSION['email'];
	
	$sql="update music set locality='$locality'  where email='$username'";
	if($con->query($sql)){
		echo $json=json_encode("success");
	}else{
		echo $con->error;
	}
	  	
	  ?>