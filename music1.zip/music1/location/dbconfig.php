<?php
	$host="localhost";
	$user="root";
	$pass="";
	$dbname="test";
	$con=mysqli_connect($host,$user,$pass,$dbname);
	if ($con->connect_error) {
    die ("Connection error" . $conn->connect_error);
} else
 {

	}
	?>
