<?php 
	require_once('dbconfig.php');
	session_start();
	$city=$_GET['city'];$username=$_SESSION['email'];
	
	$sql="update music set city='$city'  where email='$username'";
	if($con->query($sql)){
		echo $json=json_encode("success");
	}else{
		echo $con->error;
	}
	  	
	  ?>