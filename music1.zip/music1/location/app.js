var mainApp=angular.module("mainApp",['ngRoute','ngSanitize']);
mainApp.config(function($routeProvider){

	$routeProvider.
		when('/profile',{
			templateurl:'profilepage.htm',
			controller:'profilectrl'
		});
});
mainApp.controller('mainController', function($scope) {
            $scope.message = "This page will be used to display add student form";
         });
mainApp.controller('profilectrl', function($scope) {
            $scope.message = "This page will be used to display add student form";
         });
