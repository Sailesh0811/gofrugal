<?php

require_once('dbconfig.php');
$_POST = file_get_contents('php://input');
$useremail=$_POST['source0'];
$userpass=$_POST['source1'];
$query="select * from music where email='$useremail' and password='$userpass'";
$result=mysqli_query($connection,$query);
if(mysqli_num_rows($result)>0){
	$row = mysqli_fetch_assoc($result);
	session_start();
	$_SESSION['email']=$useremail;
	$_SESSION['username']= $row['firstname'];
	echo "success";
}
else{
	echo "error";
}
mysqli_close($connection);
?>