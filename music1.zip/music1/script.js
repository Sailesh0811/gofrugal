




 
$(document).ready(function(){
    $("#addinst").hide();
     $("#know_location").hide();
    $("#submit").click(function(){
        $("#addinst").fadeIn("6000");
        var skill;
        var firstname = $("#first_name").val();
        if(firstname.length<5){
            alert("he");
            return;
        }
        var lastname = $("#last_name").val();
        var stagename = $("#stage_name").val();
        var email = $("#email").val();
        var password = $("#password").val();
        var inputElements4 = document.getElementsByClassName('gender');
        for(var i=0; inputElements4[i]; ++i){
            if(inputElements4[i].checked){
               var gender = inputElements4[i].value;

            }
        }

        var inputElements5 = document.getElementsByClassName('type');
        for( i=0; inputElements5[i]; ++i){
            if(inputElements5[i].checked){
                var type = inputElements5[i].value;

            }
        }
        if(type == 'musician')
        {
            var inputElement1 = document.getElementsByClassName('skill');
            for( j=0; inputElement1[j]; ++j){
                if(inputElement1[j].checked){
                    skill  = inputElement1[j].value;

                    break;
                }
            }
        }
        else
        {
            var teacher = document.getElementsByClassName('teacher');
            for( j=0; teacher[j]; ++j){
                if(teacher[j].checked){
                     skill = teacher[j].value;
                    break;
                }
            }
        }
        console.log(type);
        








        
// Returns successful data submission message when the entered information is stored in database.
       
// AJAX Code To Submit Form.
           $.ajax({
        type: 'post',
        url: 'submit.php',
        async:false,

        data: {
            source0:firstname,
            source1:lastname,
            source2:email,
            source3:gender,
            source4:password,
            source5:stagename,
            source6:type
            
           
        },
        success: function( data ) {
            if(data=="error"){
                alert("Already signed up");
            location.reload();

            }
            else{
               console.log(data); 
            }
        }
    });
            
           $('#sign').fadeOut();
           

         
        
    });

$( function() {
    var string="";var skills="";
    console.log(string,skills);
    var availableTags = [
     "Vocal",
      "Acoustic Guitar",
      "Lead Guitar",
      "Rythm Guitar",
      "Drums/percussion",
      "Keyboards/piano",
      "Violin/Fiddle",
      "Flute",
      "Songwriter",
      "Bass guitar",
      "DJ/ Mixer",
      "Harmonica",
      "Saxophone",
      "Trumpet",
      "Ukulele",
      "Dholak",
      "Dumroo",
      "Ghatam",
      "Tabla",
      "Mridangam",
      "Sitar",
      "Tanpura",
      "Veena",
      "Sarangi"
    ];
    $( "input.autocomplete" ).autocomplete({
      source: availableTags
    });

   $("#add").click(function () {
 
    var level="";
        var inputElement3 = document.getElementsByClassName('skill');
         
        for(var j=0; inputElement3[j]; ++j){
            if(inputElement3[j].checked ){
                if(inputElement3[j].value !=null){
                   level+=inputElement3[j].value;
                }

            }
        }
    skills+=level+",";
   var instrument=$('#autocomplete').val();
        string+=instrument+",";
        $('input.autocomplete').val('');
        var str ='<div class="col s3  ani"><div class="card-panel teal white-text">You\'ve added<br><span class="white-text">';
        var str1 = ' </span> </div></div>';
        var g = str+string+""+str1;
        $('.ani').fadeOut();
        $('#show-card').append(g);
         Materialize.toast(instrument+" "+level, 4000);
        console.log(string,skills);
 });

   $('#submit1').click(function(){
    console.log(string+'hii');
      $.ajax({
        type: 'post',
        url: 'instrument.php',
        // dataType:"html",
    
        data: {
            source0: string,
            source1: skills                     
        },
        success: function( data ) {

        }
   
      
   });
      $('#addinst').fadeOut();
      $('#know_location').fadeIn();
  } );
});
$('#login').click(function(){
  var useremail=$('#useremail').val();
  var userpass=$('#userpass').val();
  console.log(useremail);
  $.ajax({
        type: 'post',
        url: 'login.php',
        // dataType:"html",
    
        data: {
            source0: useremail,
            source1: userpass                    
        },
        success: function( data ) {
          
          if(data="success"){
            window.location="./main.html";
          }
          else{
            //window.location="./index.html";
          }
          
        }
   
      
   });
});
$('#next').click(function(){
var seeking=$('#seeking').val();
  var description=$('#description').val();
  $.ajax({
        type: 'post',
        url: 'desc.php',
        // dataType:"html",
    
        data: {
            source0: description,
            source1: seeking                   
        },
        success: function( data ) {
          if(data=="success"){
            Materialize.toast("You,ve signed up",3000);
            window.location="./index.html";
          }
        }
   
      
   });
});
});
