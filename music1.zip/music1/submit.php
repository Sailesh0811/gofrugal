<?php

require_once('dbconfig.php');// Establishing Connection with Server..
$POST = file_get_contents('php://input');;
session_start();
//Fetching Values from URL
$firstname=$_POST['source0'];
$lastname=$_POST['source1'];
$email=$_POST['source2'];
$password=$_POST['source4'];
$stagename=$_POST['source5'];
$gender=$_POST['source3'];
$type = $_POST['source6'];
$_SESSION['email']=$email;
$_SESSION['name']=$firstname;
//Insert query
$query1="";$query="";
$query="select * from music where email='$email'";
$result = mysqli_query($connection,$query);//echo mysqli_num_rows($result);
if(mysqli_num_rows($result)>0)
{
echo "error";
}
else{
$query1="INSERT INTO music (firstname, lastname, stagename, email, password, gender,options) VALUES ('$firstname','$lastname', '$stagename','$email','$password','$gender','$type')";
if(!mysqli_query($connection,$query1)){
echo $connection->error;
}
echo json_encode("Success");
}
mysqli_close($connection); // Connection Closed

?>