<?php
require_once('dbconfig.php');

session_start();

$useremail=$_SESSION['email'];
$str = '<script>alert(';
$str .= $useremail;
$str .= ')</script>';
$userdetail= array();
$query="select * from posts order by post_id desc";
$result=mysqli_query($connection,$query);//echo mysqli_num_rows($result);
if( mysqli_num_rows($result)>0){$i=0;
    while ($row=mysqli_fetch_assoc($result)){
        $j=0;


        $userdetail[$i][$j++]=$row['username'];
        $userdetail[$i][$j++]=$row['music_name'];
        $userdetail[$i][$j++]=$row['tag1'];
        $userdetail[$i][$j++]=$row['tag2'];
        $userdetail[$i][$j++]=$row['tag3'];
        $userdetail[$i][$j++]=$row['tag4'];
        $userdetail[$i][$j++]=$row['picture'];
        $userdetail[$i][$j++]=$row['post_id'];
        $userdetail[$i][$j++]=$row['likes'];
        $userdetail[$i][$j++]=$row['videourl'];
        $userdetail[$i][$j++] = $row['music'];
        $userdetail[$i][$j++] = $row['cover_add'];
        $i++;
    }
    echo json_encode($userdetail);

}
else
{
    echo $connection->error;
}

?>