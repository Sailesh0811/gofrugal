

 $(document).ready(function(){

// console.log("ASDFASDFASDFASDFASDFASDFASDFADSf");

//  $('#postss').empty();

// $.ajax({
//         type: 'post',
//         url: 'postss.php',
//         // dataType:"html",
    
        
//        success:function(data) {

//         if(data=="error"){
//           window.location="./signup.html";

//         }else{
//                 details = JSON.parse(data);
//                 console.log(details);
//                 for(var i=0;i<details.length;i++){
//        var username=details[i][0];                
//      var music_name=details[i][1];
//      var tag1=details[i][2];
//        var tag2=details[i][3];
//        console.log(tag2);
//        var tag3=details[i][4];
//        var tag4=details[i][5];
//        var picture=details[i][6];    
//     var str = '<div id="posts"><div class="col s12 m7 "  ><div class="card horizontal"><div style="width:35%;" class="card-image"><img style="width:100%;" src="deepika.jpg"></div><div class="card-stacked" ><div class="card-content"><h5 id="songname" ><strong>';
//     str = str + music_name;
//     str  = str + '</strong></h5><p id="name"><i>';
//     str = str + username;
    
//     if(tag1 == "")
//     {
//       str = str ;
//     }
//     else
//     {
//       str = str + '</i></p><br> <p><div class="chip" id="tag1">';
//         str = str + tag1;
//     }
//     if(tag2 == "")
//     {
//       str = str ;
//     }
//     else
//     {
//       str = str + '</div><div class="chip" id="tag2">';
//     str = str + tag2;
//     }
//     if(tag3 == "")
//     {
//       str = str ;
//     }
//     else
//     {
//       str = str + '</div><div class="chip" id="tag3">';
//     str = str + tag3;
//     }
//     if(tag4 == "")
//     {
//       str = str ;
//     }
//     else
//     {
//       str = str + '</div><div class="chip" id="tag4">';
//         str = str + tag4;
//     }
    
   
//       str = str + ' </div></p></div><div class="card-action"><p><b>Time:4.13</b></p></div></div></div></div></div>';
//      $('#postss').append(str);
//  }
  
//         }

//     }
//   });
    





                  




var details;



var details="";var i=1;


$.ajax({
        type: 'post',
        url: 'profile.php',
        // dataType:"html",
    
        
       success:function( data ) {
                details = JSON.parse(data);
                console.log(details);
    var firstname=details[0][0];                
	var lastname=details[0][1];
	var stagename=details[0][2];
	var email=details[0][3];
	var gender=details[0][4];
	var options=details[0][5];
	var instruments=details[0][6];
	var level=details[0][7];
	var locality=details[0][10];
	var city=details[0][11];
	var description=details[0][12];
	var seeking=details[0][13];
var res = instruments.split(",");
		instruments="";
	for (var i = 0 ; i<res.length ; ) {
		instruments+=res[i]+"<br>";
		//console.log(i);
		i++;	
	}
	//console.log(instruments);
	document.getElementById('firstname').innerHTML=firstname;
	// document.getElementById('first').innerHTML=firstname;
		// document.getElementById('city').innerHTML=locality+","+city;
		// document.getElementById('place').innerHTML=locality+","+city;
		document.getElementById('seeking').innerHTML=seeking;
		document.getElementById('description').innerHTML=description;
		document.getElementById('instr').innerHTML=instruments;



        }
   
      
   });
});

